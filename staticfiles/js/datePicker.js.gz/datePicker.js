// script used in submitdetails.html relys on
// <script src="https://cdnjs.cloudflare.com/ajax/libs/datepicker/0.6.5/datepicker.min.js"></script>

$(function () {
    $(".datepicker").datepicker({
        format: 'YYYY-MM-DD'
    });
});
